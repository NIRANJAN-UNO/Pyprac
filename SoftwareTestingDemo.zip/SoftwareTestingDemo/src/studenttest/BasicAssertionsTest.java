package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import student.GradeCalculator;
import student.MarkValidator;

public class BasicAssertionsTest {

    @Test
    void testGradeCalculation() {

        GradeCalculator calculator = new GradeCalculator();

        String result = calculator.calculateGrade(85);

        assertEquals("A+", result);
    }


	@Test
    void testValidMarks() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(75));
    }

	@Test
    void testInvalidMarks() {

        MarkValidator validator = new MarkValidator();

        assertFalse(validator.isValid(101));
    }

	@Test
    void testObjectCreation() {

        GradeCalculator calculator = new GradeCalculator();

        assertNotNull(calculator);
    }
}