package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import student.ResultGenerator;
import student.Student;

public class IntegrationTest {

    @Test
    void testStudentResultGeneration() {

        // Arrange
        Student student = new Student("Niranjan", 85);
        ResultGenerator generator = new ResultGenerator();

        // Act
        String result = generator.generateResult(student);

        // Assert
        assertEquals("Niranjan - A+", result);
    }

    @Test
    void testFailingStudentResult() {

        // Arrange
        Student student = new Student("Arun", 35);
        ResultGenerator generator = new ResultGenerator();

        // Act
        String result = generator.generateResult(student);

        // Assert
        assertEquals("Arun - F", result);
    }

    @Test
    void testInvalidStudentMarks() {

        // Arrange
        Student student = new Student("Kumar", 101);
        ResultGenerator generator = new ResultGenerator();

        // Act
        String result = generator.generateResult(student);

        // Assert
        assertEquals("Invalid marks", result);
    }
}