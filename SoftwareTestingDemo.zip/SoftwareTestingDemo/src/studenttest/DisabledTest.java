package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import student.GradeCalculator;

public class DisabledTest {

    @Test
    void normalTest() {

        GradeCalculator calculator = new GradeCalculator();

        assertEquals("A+", calculator.calculateGrade(85));
    }

    @Test
    @Disabled("Demonstration of a disabled test")
    void disabledTest() {

        GradeCalculator calculator = new GradeCalculator();

        assertEquals("This test should not run",
                     calculator.calculateGrade(85));
    }
}