package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import student.GradeCalculator;

public class DecisionTableTest {

    @Test
    void testInvalidMarks() {

        GradeCalculator calculator = new GradeCalculator();

        assertFalse(calculator.isPass(-10));
    }

    @Test
    void testValidMarksBelowPassMark() {

        GradeCalculator calculator = new GradeCalculator();

        assertFalse(calculator.isPass(35));
    }

    @Test
    void testValidMarksAtPassMark() {

        GradeCalculator calculator = new GradeCalculator();

        assertTrue(calculator.isPass(40));
    }

    @Test
    void testValidMarksAbovePassMark() {

        GradeCalculator calculator = new GradeCalculator();

        assertTrue(calculator.isPass(75));
    }
}