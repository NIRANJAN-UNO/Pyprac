package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import student.InputValidator;

public class ExceptionTest {

    @Test
    void testValidMarksDoesNotThrowException() {

        InputValidator validator = new InputValidator();

        assertDoesNotThrow(() -> {
            validator.validateMarks(75);
        });
    }

    @Test
    void testNegativeMarksThrowsException() {

        InputValidator validator = new InputValidator();

        assertThrows(
            IllegalArgumentException.class,
            () -> validator.validateMarks(-1)
        );
    }

    @Test
    void testMarksAbove100ThrowsException() {

        InputValidator validator = new InputValidator();

        assertThrows(
            IllegalArgumentException.class,
            () -> validator.validateMarks(101)
        );
    }
    @Test
    void testExceptionMessage() {

        InputValidator validator = new InputValidator();

        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> validator.validateMarks(-1)
        );

        assertEquals(
            "Marks must be between 0 and 100",
            exception.getMessage()
        );
    }
}