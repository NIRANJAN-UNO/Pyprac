package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import student.CoverageDemo;

public class ConditionCoverageTest {

    @Test
    void testNegativeMarks() {

        CoverageDemo demo = new CoverageDemo();

        assertEquals("Invalid", demo.evaluateMarks(-1));
    }

    @Test
    void testValidMarks() {

        CoverageDemo demo = new CoverageDemo();

        assertEquals("Pass", demo.evaluateMarks(75));
    }

    @Test
    void testMarksAbove100() {

        CoverageDemo demo = new CoverageDemo();

        assertEquals("Invalid", demo.evaluateMarks(101));
    }
}