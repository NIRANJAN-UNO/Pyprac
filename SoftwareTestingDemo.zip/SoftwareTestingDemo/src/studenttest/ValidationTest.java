package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import student.GradeCalculator;
import student.MarkValidator;

public class ValidationTest {

    @Test
    @Tag("validation")
    void validateMinimumMarks() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(0));
    }

    @Test
    @Tag("validation")
    void validateMaximumMarks() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(100));
    }

    @Test
    @Tag("validation")
    void validateNegativeMarks() {

        MarkValidator validator = new MarkValidator();

        assertFalse(validator.isValid(-1));
    }

    @Test
    @Tag("validation")
    void validateMarksAboveMaximum() {

        MarkValidator validator = new MarkValidator();

        assertFalse(validator.isValid(101));
    }

    @Test
    @Tag("validation")
    void validateGradeForPassMark() {

        GradeCalculator calculator = new GradeCalculator();

        assertEquals("C", calculator.calculateGrade(40));
    }

    @Test
    @Tag("validation")
    void validateGradeForHighestRange() {

        GradeCalculator calculator = new GradeCalculator();

        assertEquals("A+", calculator.calculateGrade(100));
    }
}