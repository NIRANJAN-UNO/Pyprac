package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import student.MarkValidator;

public class BoundaryValueTest {

    @Test
    void testBelowLowerBoundary() {

        MarkValidator validator = new MarkValidator();

        assertFalse(validator.isValid(-1));
    }

    @Test
    void testLowerBoundary() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(0));
    }

    @Test
    void testAboveLowerBoundary() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(1));
    }

    @Test
    void testBelowUpperBoundary() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(99));
    }

    @Test
    void testUpperBoundary() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(100));
    }

    @Test
    void testAboveUpperBoundary() {

        MarkValidator validator = new MarkValidator();

        assertFalse(validator.isValid(101));
    }
}