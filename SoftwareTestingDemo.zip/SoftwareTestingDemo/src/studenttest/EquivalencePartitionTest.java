package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import student.MarkValidator;

public class EquivalencePartitionTest {

    @Test
    void testInvalidNegativeMarks() {

        MarkValidator validator = new MarkValidator();

        assertFalse(validator.isValid(-10));
    }

    @Test
    void testValidMarks() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(50));
    }

    @Test
    void testInvalidMarksAbove100() {

        MarkValidator validator = new MarkValidator();

        assertFalse(validator.isValid(110));
    }
}