package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import student.CoverageDemo;

public class StatementCoverageTest {

    @Test
    void testInvalidMarks() {

        CoverageDemo demo = new CoverageDemo();

        assertEquals("Invalid", demo.evaluateMarks(-1));
    }

    @Test
    void testPassingMarks() {

        CoverageDemo demo = new CoverageDemo();

        assertEquals("Pass", demo.evaluateMarks(75));
    }

    @Test
    void testFailingMarks() {

        CoverageDemo demo = new CoverageDemo();

        assertEquals("Fail", demo.evaluateMarks(30));
    }
}