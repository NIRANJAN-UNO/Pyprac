package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import student.GradeCalculator;
import student.MarkValidator;

public class TaggedTest {

    @Test
    @Tag("unit")
    void testGradeCalculation() {

        GradeCalculator calculator = new GradeCalculator();

        assertEquals("A+", calculator.calculateGrade(85));
    }

    @Test
    @Tag("unit")
    void testMarkValidation() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(50));
    }

    @Test
    @Tag("blackbox")
    void testBoundaryValue() {

        MarkValidator validator = new MarkValidator();

        assertTrue(validator.isValid(100));
    }

    @Test
    @Tag("integration")
    void testResultGeneration() {

        student.Student student =
                new student.Student("Niranjan", 85);

        student.ResultGenerator generator =
                new student.ResultGenerator();

        assertEquals(
                "Niranjan - A+",
                generator.generateResult(student)
        );
    }
}