package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import student.MarkValidator;

public class ParameterizedTestDemo {

    @ParameterizedTest
    @CsvSource({
        "-1, false",
        "0, true",
        "1, true",
        "99, true",
        "100, true",
        "101, false"
    })
    void testBoundaryValues(int marks, boolean expected) {

        MarkValidator validator = new MarkValidator();

        assertEquals(expected, validator.isValid(marks));
    }
}