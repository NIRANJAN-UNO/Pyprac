package studenttest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import student.GradeCalculator;

public class LifecycleTest {

    private GradeCalculator calculator;

    @BeforeAll
    static void setupAll() {

        System.out.println("=== BeforeAll: Test class starting ===");
    }

    @BeforeEach
    void setupEach() {

        calculator = new GradeCalculator();

        System.out.println("BeforeEach: Creating calculator");
    }

    @Test
    void testGradeAPlus() {

        assertEquals("A+", calculator.calculateGrade(85));

        System.out.println("Test: A+");
    }

    @Test
    void testGradeFail() {

        assertEquals("F", calculator.calculateGrade(30));

        System.out.println("Test: F");
    }

    @AfterEach
    void cleanupEach() {

        calculator = null;

        System.out.println("AfterEach: Cleaning calculator");
    }

    @AfterAll
    static void cleanupAll() {

        System.out.println("=== AfterAll: Test class finished ===");
    }
}