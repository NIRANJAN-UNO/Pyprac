package student;

public class CoverageDemo {

    public String evaluateMarks(int marks) {

        if (marks < 0 || marks > 100) {
            return "Invalid";
        }

        if (marks >= 40) {
            return "Pass";
        }

        return "Fail";
    }
}