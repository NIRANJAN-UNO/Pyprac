package student;

public class MarkValidator {

    public boolean isValid(int marks) {

        if (marks < 0 || marks > 100) {
            return false;
        }

        return true;
    }
}
