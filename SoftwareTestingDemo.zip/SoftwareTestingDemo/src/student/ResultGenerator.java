package student;

public class ResultGenerator {

    private MarkValidator validator;
    private GradeCalculator gradeCalculator;

    public ResultGenerator() {
        validator = new MarkValidator();
        gradeCalculator = new GradeCalculator();
    }

    public String generateResult(Student student) {

        if (!validator.isValid(student.getMarks())) {
            return "Invalid marks";
        }

        String grade = gradeCalculator.calculateGrade(student.getMarks());

        return student.getName() + " - " + grade;
    }
}