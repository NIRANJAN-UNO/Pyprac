package student;

public class GradeCalculator {

    public String calculateGrade(int marks) {

        if (marks < 0 || marks > 100) {
            return "Invalid";
        }

        if (marks >= 75) {
            return "A+";
        } else if (marks >= 60) {
            return "A";
        } else if (marks >= 50) {
            return "B";
        } else if (marks >= 40) {
            return "C";
        } else {
            return "F";
        }
    }
    public boolean isPass(int marks) {

        if (marks < 0 || marks > 100) {
            return false;
        }

        return marks >= 40;
    }
}