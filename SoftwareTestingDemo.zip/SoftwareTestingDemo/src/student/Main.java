package student;

public class Main {

    public static void main(String[] args) {

        Student student1 = new Student("Niranjan", 85);
        Student student2 = new Student("Arun", 65);
        Student student3 = new Student("Kumar", 35);
        Student student4 = new Student("Ravi", 101);

        ResultGenerator generator = new ResultGenerator();

        System.out.println(generator.generateResult(student1));
        System.out.println(generator.generateResult(student2));
        System.out.println(generator.generateResult(student3));
        System.out.println(generator.generateResult(student4));
    }
}