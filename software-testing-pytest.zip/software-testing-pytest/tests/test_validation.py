import pytest

from app.mark_validator import MarkValidator
from app.grade_calculator import GradeCalculator


@pytest.mark.validation
def test_minimum_valid_marks():

    validator = MarkValidator()

    assert validator.is_valid(0) is True


@pytest.mark.validation
def test_maximum_valid_marks():

    validator = MarkValidator()

    assert validator.is_valid(100) is True


@pytest.mark.validation
def test_negative_marks_are_rejected():

    validator = MarkValidator()

    assert validator.is_valid(-1) is False


@pytest.mark.validation
def test_marks_above_100_are_rejected():

    validator = MarkValidator()

    assert validator.is_valid(101) is False


@pytest.mark.validation
def test_pass_requirement():

    calculator = GradeCalculator()

    assert calculator.calculate_grade(40) == "Pass"


@pytest.mark.validation
def test_highest_marks_requirement():

    calculator = GradeCalculator()

    assert calculator.calculate_grade(100) == "Pass"