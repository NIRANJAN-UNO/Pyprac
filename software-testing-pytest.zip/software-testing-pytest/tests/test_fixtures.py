import pytest

from app.mark_validator import MarkValidator


@pytest.fixture
def validator():

    return MarkValidator()


def test_valid_marks(validator):

    assert validator.is_valid(50) is True


def test_invalid_marks(validator):

    assert validator.is_valid(150) is False


def test_boundary_marks(validator):

    assert validator.is_valid(100) is True