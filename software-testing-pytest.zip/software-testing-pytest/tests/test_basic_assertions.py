from app.mark_validator import MarkValidator


def test_valid_marks():
    validator = MarkValidator()

    assert validator.is_valid(75) is True


def test_invalid_marks():
    validator = MarkValidator()

    assert validator.is_valid(101) is False


def test_boundary_mark():
    validator = MarkValidator()

    assert validator.is_valid(100) is True