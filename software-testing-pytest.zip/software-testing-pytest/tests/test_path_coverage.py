from app.coverage_demo import CoverageDemo


def test_path_invalid():
    demo = CoverageDemo()

    assert demo.evaluate_marks(-1) == "Invalid"


def test_path_pass():
    demo = CoverageDemo()

    assert demo.evaluate_marks(75) == "Pass"


def test_path_fail():
    demo = CoverageDemo()

    assert demo.evaluate_marks(30) == "Fail"