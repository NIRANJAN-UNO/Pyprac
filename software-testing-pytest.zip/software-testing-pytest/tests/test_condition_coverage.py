from app.coverage_demo import CoverageDemo


def test_negative_marks():
    demo = CoverageDemo()

    assert demo.evaluate_marks(-1) == "Invalid"


def test_valid_marks():
    demo = CoverageDemo()

    assert demo.evaluate_marks(75) == "Pass"


def test_marks_above_100():
    demo = CoverageDemo()

    assert demo.evaluate_marks(101) == "Invalid"