import pytest

from app.student import Student
from app.result_generator import ResultGenerator


@pytest.mark.integration
def test_student_result_generation():

    student = Student("Niranjan", 85)
    generator = ResultGenerator()

    result = generator.generate_result(student)

    assert result == "Niranjan - Pass"


@pytest.mark.integration
def test_failing_student_result():

    student = Student("Arun", 35)
    generator = ResultGenerator()

    result = generator.generate_result(student)

    assert result == "Arun - Fail"


@pytest.mark.integration
def test_invalid_student_marks():

    student = Student("Kumar", 101)
    generator = ResultGenerator()

    result = generator.generate_result(student)

    assert result == "Invalid marks"