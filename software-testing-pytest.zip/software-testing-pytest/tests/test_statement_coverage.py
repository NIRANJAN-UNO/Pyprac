from app.coverage_demo import CoverageDemo


def test_invalid_marks():
    demo = CoverageDemo()

    assert demo.evaluate_marks(-1) == "Invalid"


def test_passing_marks():
    demo = CoverageDemo()

    assert demo.evaluate_marks(75) == "Pass"


def test_failing_marks():
    demo = CoverageDemo()

    assert demo.evaluate_marks(30) == "Fail"