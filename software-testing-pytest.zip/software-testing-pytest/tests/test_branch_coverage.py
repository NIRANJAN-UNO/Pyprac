from app.coverage_demo import CoverageDemo


def test_invalid_branch():
    demo = CoverageDemo()

    assert demo.evaluate_marks(-1) == "Invalid"


def test_pass_branch():
    demo = CoverageDemo()

    assert demo.evaluate_marks(75) == "Pass"


def test_fail_branch():
    demo = CoverageDemo()

    assert demo.evaluate_marks(30) == "Fail"