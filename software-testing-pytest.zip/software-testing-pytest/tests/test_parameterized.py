import pytest

from app.mark_validator import MarkValidator


@pytest.mark.parametrize(
    "marks, expected",
    [
        (-1, False),
        (0, True),
        (1, True),
        (99, True),
        (100, True),
        (101, False)
    ]
)
def test_mark_boundaries(marks, expected):

    validator = MarkValidator()

    assert validator.is_valid(marks) is expected



#pytest -v run on command.