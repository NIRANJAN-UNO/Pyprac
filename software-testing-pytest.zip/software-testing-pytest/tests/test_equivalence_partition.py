from app.mark_validator import MarkValidator


def test_negative_marks():
    validator = MarkValidator()

    assert validator.is_valid(-10) is False


def test_valid_marks():
    validator = MarkValidator()

    assert validator.is_valid(50) is True


def test_marks_above_100():
    validator = MarkValidator()

    assert validator.is_valid(110) is False