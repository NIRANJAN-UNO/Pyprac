from app.grade_calculator import GradeCalculator


def test_invalid_marks():
    calculator = GradeCalculator()

    assert calculator.calculate_grade(-10) == "Invalid"


def test_valid_marks_below_pass_mark():
    calculator = GradeCalculator()

    assert calculator.calculate_grade(35) == "Fail"


def test_valid_marks_at_pass_mark():
    calculator = GradeCalculator()

    assert calculator.calculate_grade(40) == "Pass"


def test_valid_marks_above_pass_mark():
    calculator = GradeCalculator()

    assert calculator.calculate_grade(75) == "Pass"