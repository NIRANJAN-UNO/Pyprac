import pytest

from app.mark_validator import MarkValidator


def test_valid_marks_do_not_raise_exception():

    validator = MarkValidator()

    assert validator.validate(75) is True


def test_negative_marks_raise_exception():

    validator = MarkValidator()

    with pytest.raises(ValueError):
        validator.validate(-1)


def test_marks_above_100_raise_exception():

    validator = MarkValidator()

    with pytest.raises(ValueError):
        validator.validate(101)