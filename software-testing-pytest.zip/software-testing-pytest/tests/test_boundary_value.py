from app.mark_validator import MarkValidator


def test_below_lower_boundary():
    validator = MarkValidator()

    assert validator.is_valid(-1) is False


def test_lower_boundary():
    validator = MarkValidator()

    assert validator.is_valid(0) is True


def test_above_lower_boundary():
    validator = MarkValidator()

    assert validator.is_valid(1) is True


def test_below_upper_boundary():
    validator = MarkValidator()

    assert validator.is_valid(99) is True


def test_upper_boundary():
    validator = MarkValidator()

    assert validator.is_valid(100) is True


def test_above_upper_boundary():
    validator = MarkValidator()

    assert validator.is_valid(101) is False