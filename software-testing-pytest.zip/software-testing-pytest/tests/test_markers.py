import pytest

from app.mark_validator import MarkValidator
from app.grade_calculator import GradeCalculator


@pytest.mark.unit
def test_mark_validator():

    validator = MarkValidator()

    assert validator.is_valid(50) is True


@pytest.mark.blackbox
def test_boundary_value():

    validator = MarkValidator()

    assert validator.is_valid(100) is True


@pytest.mark.whitebox
def test_grade_branch():

    calculator = GradeCalculator()

    assert calculator.calculate_grade(75) == "Pass"


@pytest.mark.integration
def test_components_work_together():

    validator = MarkValidator()
    calculator = GradeCalculator()

    marks = 75

    assert validator.is_valid(marks) is True
    assert calculator.calculate_grade(marks) == "Pass"