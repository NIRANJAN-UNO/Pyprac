from app.mark_validator import MarkValidator
from app.grade_calculator import GradeCalculator


class ResultGenerator:

    def __init__(self):
        self.validator = MarkValidator()
        self.calculator = GradeCalculator()

    def generate_result(self, student):

        if not self.validator.is_valid(student.marks):
            return "Invalid marks"

        grade = self.calculator.calculate_grade(student.marks)

        return f"{student.name} - {grade}"