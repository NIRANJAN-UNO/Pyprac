class MarkValidator:

    def is_valid(self, marks):
        return 0 <= marks <= 100

    def validate(self, marks):

        if not self.is_valid(marks):
            raise ValueError("Marks must be between 0 and 100")

        return True